package Ooops;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayUse {
    public static int[] takeInput(){
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int input[] = new int[size];
        for(int i=0;i<size;i++){
            input[i] = sc.nextInt();

        }
        return input;

    }
    public static void print(int input[]) {
    int size = input.length;

        for (int i = 0; i < size; i++) {
            System.out.print(input[i] + "  ");
        }
    }
    public static int MaxArr(int input[]){
        int max = 0;
        for(int i=0;i<input.length;i++){
            if(input[i]>=max){
                max = input[i];
            }
        }
        return max;
    }

    public static void main(String[] args) {
    int a[] =takeInput();
    print(a);
        System.out.println("maximum element in array" +MaxArr(a));
    }
}
