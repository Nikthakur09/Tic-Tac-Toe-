package Ooops;

public class ComplexNumberUse {
    public static void main(String[] args) {
        Complex c1 = new Complex(2,3);
        c1.print();
        Complex c2 = new Complex(5,6);
        c1.multiply(c2);
        c1.print();
        c1.plus(c2);
        c2.print();
        c1.print();



    }
}



