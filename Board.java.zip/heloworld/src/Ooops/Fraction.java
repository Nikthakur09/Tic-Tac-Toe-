package Ooops;

public class Fraction {
        private int den ;
        private int num ;
        public Fraction(int num,int den){
            this.num =num;
            if(den==0){
                System.out.println("error");
            }
            else {
                this.den = den;
                simplify();
            }
        simplify();
        }
        public int getDen(){
            return den;
        }
        public int getNum(){
        return num;

        }
        public void setNum(int n){
            this.num=n;
            simplify();
        }
    public void setDen(int d){
        this.den=d;
        simplify();
    }
   private void simplify(){
            int gcd =1;
             int smaller = Math.min(num,den);
            for(int i=1;i<smaller;i++){
                if(num%i==0 && den%i==0){
                    gcd=i;
                }
            }
            num = this.num/gcd;
            den = this.den/gcd;
    }
    public void print(){
        System.out.println(num + " / "+  den );
    }
    public void add(Fraction F2, Fraction F3){
            num  = this.num*F2.den + this.den*F2.num;
            den = this.den*F2.den;
            simplify();
        }
//    public static Fraction add(Fraction F1,Fraction F2)
//    {
//     int newNum =  F1.num*F2.den + F1.den*F2.num;
//       int newDen = F1.den*F2.den;
//       Fraction F = new Fraction(newNum,newDen);
//
//       return F;



    public void multiply(Fraction F2){
            num = this.num*F2.num;
            den = this.den*F2.den;
            simplify();
    }

}
