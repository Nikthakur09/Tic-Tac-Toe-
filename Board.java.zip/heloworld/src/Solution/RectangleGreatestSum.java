package Solution;

import java.util.Arrays;

import static Solution.KadaneAlgo.maxSubarraySum;

public class RectangleGreatestSum{
int maxSumRectangle(int r,int c, int m[][]){
    int sum[] = new int[r];
    int maxsum = Integer.MIN_VALUE;
    for(int i = 0;i<c;i++){
        Arrays.fill(sum,0);
        for(int j=i;j<c;j++){
           for(int row = 0 ;row<0;row++){
               sum[row] += m[row][j];
           }
           int curMaxSum;
            curMaxSum = kadans(sum );
            maxsum = Math.max(maxsum,curMaxSum);

        }
    }
    return maxsum;
}

    public static void main(String[] args) {
        RectangleGreatestSum r = new RectangleGreatestSum();

    }
int kadans(int arr[]){
    int n = arr.length;
    int sum =0;
    int maxi = arr[0];
    for (int i = 0;i<n;i++){

        sum = sum + arr[i];

        maxi = Math.max(sum,maxi);

        if(sum<0){
            sum=0;
        }

    }
    if (maxi<0){
        maxi =0;
    }
    return maxi;
}
}


