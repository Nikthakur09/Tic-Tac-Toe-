package Solution;

public class consecutiveDuplicates {
}
