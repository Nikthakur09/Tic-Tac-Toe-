package Solution;

public class KadaneAlgo {
    public static int maxSubarraySum(int[] arr, int n) {
        int sum =0;
        int maxi = arr[0];
        for (int i = 0;i<n;i++){

            sum = sum + arr[i];

            maxi = Math.max(sum,maxi);

            if(sum<0){
                sum=0;
            }

        }
        if (maxi<0){
            maxi =0;
        }
        return maxi;
    }

}


