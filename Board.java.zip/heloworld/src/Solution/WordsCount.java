package Solution;

import java.util.Scanner;

public class WordsCount {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String A = sc.nextLine();

        String z = "0";
        for (int i = 0; i < A.length(); i++) {
            if (A.charAt(i) == 'a') {
              z = A.substring(i+1);

            }
        z = z;
        }
        System.out.println(z);
    }
}
