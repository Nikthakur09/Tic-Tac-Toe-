package Ooops;

import java.sql.SQLOutput;
import java.util.Scanner;

public class sumTarget {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int target = s.nextInt();
        int size = s.nextInt();
        int arr[] = new int[size];
        for(int i=0; i<size;i++){
            arr[i] = s.nextInt();
        }
        for (int j = 0; j< size;j++){
            for (int k=j;k<size;k++){
                if(target ==arr[j]+arr[k]){
                    if(j==k){
                        System.out.println(" ");
                    }else {
                        System.out.println("[ " + +j + " , " + +k + " ]");
                    }
                }
            }
        }
    }
}