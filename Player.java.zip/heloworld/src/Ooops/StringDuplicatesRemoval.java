package Ooops;
import jdk.jshell.Snippet;
import java.util.Scanner;

public class StringDuplicatesRemoval {
    public String StringRem() {
        String res = "";

        Scanner sc = new Scanner(System.in);
        String S = sc.nextLine();
        int n = S.length();
        for (int i = 0; i < n ; i++) {
            if (i < n || S.charAt(i) == S.charAt(i + 1)) {
                break;
            }
            else

            res += S.charAt(i);

        }
        return res;

    }

    public static void main(String[] args) {
        StringDuplicatesRemoval sc = new StringDuplicatesRemoval();
        String st = sc.StringRem();
        sc.StringRem();
        System.out.println(st);
    }
}