package Ooops;

public class Complex {
    private int real;
    private int imagnary;

    public Complex(int r, int i) {
        this.real = r;
        this.imagnary = i;
    }

    public void print() {
        if (imagnary > 0) {
            System.out.println(real + " + i" + imagnary);
        } else {
            imagnary = imagnary * -1;
            System.out.println(real + " - i" + imagnary);
        }
    }

    public void plus(Complex c2)
    {
     this.real = this.real + c2.real;
     this.imagnary = this.imagnary + c2.imagnary;
    }
    public void multiply(Complex c2) {
        this.real = this.real * c2.real - this.imagnary * c2.imagnary;
        this.imagnary = this.real * c2.imagnary + this.imagnary * c2.real;

    }
}
