package Ooops;

public class Fractionuse {
    public static void main(String[] args) {
          Fraction F1 = new Fraction(20,30);
          F1.print();
          F1.setDen(12);
          int d = F1.getDen();
        System.out.println(d);
          F1.print();
          F1.setNum(10);
        F1.setDen(10);
        F1.print();
        Fraction F2 = new Fraction(3,4);

        F1.print();
        F2.print();
        Fraction F3 = new Fraction(4,5);
        F3.multiply(F2);
        F3.print();
        F2.print();
//        Fraction  F4 = Fraction.add(F1,F3);
//        F1.print();
//        F3.print();
//        F4.print();
    }
}
