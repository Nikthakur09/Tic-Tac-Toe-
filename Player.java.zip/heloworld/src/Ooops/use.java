package Ooops;

import java.util.ArrayList;


public class use {
//    public static void main(String[] args) {
//        String stu = StringDuplicatesRemoval;
//        System.out.println();
//    }
//
//}



//    public static void quickSortUsingDutchNationalFlag (ArrayList < Integer > arr) {
//        // Write your code here.
//
//        ArrayList<Integer> ls = new ArrayList<Integer>();
//        Collections.sort(arr);
//        for (int i = 0; i < arr.size(); i++) {
//            ls.add(i, arr.get(i));
//        }
//        System.out.println((ls));
//
//    }
//
//    public static void main(String[] args) {
//        int arr[] = {2,3,4,5,6,7,8,8};
//        System.out.println(quickSortUsingDutchNationalFlag(arr));
//    }
//

//ArrayList<Integer> list1 = new ArrayList<>();
//list1.add(20);
}
