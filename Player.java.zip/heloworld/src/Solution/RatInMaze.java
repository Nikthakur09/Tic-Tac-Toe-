package Solution;

public class RatInMaze {
    public static void main(String[] args) {
        int x = power(5,3);
        System.out.println(x);
        print(1000);
    }
    public static int power(int n, int p){
        if(n==0){
            return 0;
        }
        if(p==0){
            return 1;
        }
        int sum =1;
        for(int i=1;i<n;i++){
         sum = sum *p;
            }
        return sum*p;
    }
    public static void print(int n){
        if(n==0){
            return;
        }
        else{
            System.out.print(n + " ");
          print(n-1);
        }
        return;
    }

}
