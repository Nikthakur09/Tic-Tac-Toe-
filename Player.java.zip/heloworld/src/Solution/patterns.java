package Solution;

import java.util.Scanner;

public class patterns {
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        for (int i = 1; i<a;i++){
            int count =  1;
            for (int j= 0; j<i;j++){
                System.out.print(i);
            }
            System.out.println();

        }
    }
}