package Projects;

import jdk.jshell.Snippet;

import java.util.Scanner;

public class TicTacToe {
       private Player p1, p2;
       private Board board;

       public static void main(String[] args) {
              TicTacToe t = new TicTacToe();
              t.startGame();
       }
       // how game is running
       public void startGame() {
              Scanner s = new Scanner(System.in);
              p1 = takeInput(1);
              p2 = takeInput(2);
              while (p1.getSymbol() == p2.getSymbol()) {
                     System.out.println("Symbol already taken !!!  take different one :) ");
                     char symbol = s.next().charAt(0);
                     p2.setSymbol(symbol);

              }
              board = new Board(p1.getSymbol(), p2.getSymbol());
              boolean p1Turn = true;
              int status = Board.INCOMPLETE;
              while (status == Board.INVALD || status == Board.INCOMPLETE) {
                     if (p1Turn) {
                            System.out.println("Player 1 - " + p1.getName() + "'s turn !!!");
                            System.out.println("Enter x cordinate ");
                            int x = s.nextInt();
                            System.out.println("Enter y cordinate ");
                            int y = s.nextInt();
                            status = board.move(p1.getSymbol(), x, y);
                            if (status != Board.INVALD) {
                                   p1Turn = false;
                                   board .print();
                            }
                            else{
                                   System.out.println(" Invalid move try again!!!");
                            }
                     } else {
                            System.out.println("Player 2 - " + p2.getName() + "'s turn !!!");
                            System.out.println("Enter x cordinate ");
                            int x = s.nextInt();
                            System.out.println("Enter y cordinate ");
                            int y = s.nextInt();
                             status = board.move(p2.getSymbol(), x, y);
                            if (status != Board.INVALD) {
                                   p1Turn = true;
                                   board.print();
                            }
                            else{
                                   System.out.println(" Invalid move try again!!!");
                            }

                     }
              }
              if(status == Board.PLAYER_1_WINS){
                     System.out.println("Player 1 " + p1.getName() + " wins !!!! ");
              }
              else if(status == Board.PLAYER_2_WINS){
                     System.out.println("Player 2 " + p2.getName() + " wins !!!! ");
              }
              else{
                     System.out.println(" it's a tie ");
              }
       }

       //User se input liya hai
       public Player takeInput(int num) {
              Scanner sc = new Scanner(System.in);
              System.out.println("Enter Player " + num + "Name : ");
              String name = sc.nextLine();
              System.out.println("Enter Player " + num + "Symbol : ");
              char symbol = sc.next().charAt(0);
              Player p = new Player(name, symbol);
              return p;
       }


}
